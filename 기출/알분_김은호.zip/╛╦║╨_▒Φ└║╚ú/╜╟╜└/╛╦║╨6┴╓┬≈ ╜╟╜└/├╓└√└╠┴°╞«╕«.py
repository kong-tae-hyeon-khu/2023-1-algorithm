import numpy as np


class Node:
    def __init__(self, data):
        self.l_child = None
        self.r_child = None
        self.data = data


def tree(key, r, i, j):
    k = r[i][j]
    if(k == 0):
        return
    else:
        p = Node(key[k])
        p.l_child = tree(key, r, i, k-1)
        p.r_child = tree(key, r, k+1, j)
        return p


def inOrder(root):
    if not root:
        return
    inOrder(root.l_child)
    print(root.data)
    inOrder(root.r_child)


def preOrder(root):
    if not root:
        return
    print(root.data)
    preOrder(root.l_child)
    preOrder(root.r_child)


def optSearchTree(n, p, a, r):  # n: 트리 노드 개수, p: 검색키일 확률 = 이 키를 검색하는 평균 시간
    # a : 최소시간 저장 행렬, r : 최적트리일 때의 루트 저장
    for i in range(1, n+1):
        a[i][i] = p[i]
        r[i][i] = i

    for diag in range(1, n):
        for i in range(1, n-diag+1):
            j = i + diag
            psum = sum(p[i:j+1])
            for k in range(i, j+1):  # range(1, 4)이면 1번노드부터 4번노드까지의 최솟값찾기, 가능한 루트는 1번부터 4번
                compareValue = a[i][k-1] + a[k+1][j]
                if(a[i][j] == 0):  # 최초로 a[i][j]에 접근할 때
                    a[i][j] = compareValue
                    r[i][j] = k
                else:
                    if(a[i][j] > compareValue):
                        r[i][j] = k
                        a[i][j] = compareValue
            a[i][j] += psum  # 34줄이나 36줄에 넣으면 pm값이 중복으로 더해짐


'''
최소곱셈과 비슷하게 대각선 1 : 노드가 두 개일 때의 최소값, A[1][2], A[2][3] 등
대각선 2: 노드가 세 개일 때, A[1][3] 등
'''

n = int(input())
a = np.zeros((n+2, n+2))
r = np.zeros((n+2, n+2), dtype=int)
key = np.array([' ', 'A', 'B', 'C', 'D'])
p = np.array([0, 0.375, 0.375, 0.125, 0.125])

optSearchTree(n, p, a, r)

print(a)
print()
print(r)

tr = tree(key, r, 1, n)
preOrder(tr)
inOrder(tr)
'''
for i in range(1, n+1):
        a[i][i-1] = 0
        a[i][i] = p[i]
        r[i][i] = i
        r[i][i-1] = 0
    a[n+1][n] = r[n+1][n] = 0
'''
