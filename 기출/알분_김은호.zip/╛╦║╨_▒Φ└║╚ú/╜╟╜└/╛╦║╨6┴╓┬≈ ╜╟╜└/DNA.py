import numpy as np


def fillTable(x, y, table, minindex):
    for i in range(len(x)-1, -1, -1):
        j = len(y)-1
        while(i < len(x) and j >= 0):
            penalty = 0 if x[i] == y[j] else 1
            a = table[i+1][j+1] + penalty
            b = table[i+1][j]+2
            c = table[i][j+1]+2
            table[i][j] = min(a, b, c)
            if min(a, b, c) == a:
                minindex[i][j] = (i+1, j+1)
            elif min(a, b, c) == b:
                minindex[i][j] = (i+1, j)
            else:
                minindex[i][j] = (i, j+1)
            i += 1
            j -= 1
    for j in range(len(y)-2, -1, -1):
        i = 0
        while(i <= len(y)-2 and j >= 0):
            penalty = 0 if x[i] == y[j] else 1
            a = table[i+1][j+1] + penalty
            b = table[i+1][j]+2
            c = table[i][j+1]+2
            table[i][j] = min(a, b, c)
            if min(a, b, c) == a:
                minindex[i][j] = (i+1, j+1)
            elif min(a, b, c) == b:
                minindex[i][j] = (i+1, j)
            else:
                minindex[i][j] = (i, j+1)
            i += 1
            j -= 1


def print_minindex(a, b, minindex):
    x = y = 0
    while (x < len(a) and y < len(b)):
        tx, ty = x, y
        print(minindex[x][y])
        (x, y) = minindex[x][y]
        if x == tx+1 and y == ty+1:
            print(a[tx], " ", b[ty])
        elif x == tx and y == ty+1:
            print(" - ", " ", b[ty])

        else:
            print(a[tx], " ", " -")


def printMatrix(d):
    m = len(d)
    n = len(d[0])

    for i in range(0, m):
        for j in range(0, n):
            print('{0:2}'.format(d[i][j]), end=" ")
        print()


def main2():
    a = ['A', 'A', 'C', 'A', 'G', 'T', 'T', 'A', 'C', 'C']
    b = ['T', 'A', 'A', 'G', 'G', 'T', 'C', 'A']

    m = len(a)
    n = len(b)
    table = [[0 for j in range(0, n+1)] for i in range(0, m+1)]
    minindex = [[(0, 0) for j in range(1, n+1)] for i in range(0, m+1)]

    for j in range(n-1, -1, -1):
        table[m][j] = table[m][j+1] + 2
    for i in range(m-1, -1, -1):
        table[i][n] = table[i+1][n] + 2
    fillTable(a, b, table, minindex)
    printMatrix(table)
    print()

    print_minindex(a, b, minindex)


main2()
