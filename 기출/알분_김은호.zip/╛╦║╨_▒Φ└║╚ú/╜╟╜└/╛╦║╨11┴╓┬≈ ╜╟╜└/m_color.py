def m_coloring(i, vcolor):
    if(promising(i, vcolor)):
        if(i == n-1):
            print(vcolor)
        else:
            for color in range(1, m+1):  # 1부터 m까지의 색
                vcolor[i+1] = color
                m_coloring(i+1, vcolor)


def promising(i, vcolor):
    switching = True
    j = 0
    while(j < i and switching):
        if(W[i][j] and vcolor[i] == vcolor[j]):  # 연결되어 있고 서로 색이 같으면 False
            switching = False                   # 정점 0부터 색을 칠해가므로 j = 0부터 시작, j < i 까지
        j += 1
    return switching


n = 4
W = [[0, 1, 1, 1], [1, 0, 1, 0], [1, 1, 0, 1], [1, 0, 1, 0]]
vcolor = n*[0]
m = 3
m_coloring(-1, vcolor)
