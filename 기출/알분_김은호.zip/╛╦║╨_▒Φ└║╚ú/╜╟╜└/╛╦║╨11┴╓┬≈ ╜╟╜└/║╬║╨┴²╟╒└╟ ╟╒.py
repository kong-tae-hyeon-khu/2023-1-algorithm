def promising(i, weight, total):
    return (weight+total >= W) and (weight == W or weight+w[i+1] <= W)
# non-promising 조건: weight + total < W or (weight + w[i+1] > W) and (weight != W)
# promising 여부를 구하기 위해 non-promising 조건에 ~을 붙임


def s_s(i, weight, total, include):
    if(promising(i, weight, total)):
        if(weight == W):
            print(include)
        else:
            include[i+1] = 1
            s_s(i+1, weight+w[i+1], total-w[i+1], include)  # w[i+1] 포함
            include[i+1] = 0
            s_s(i+1, weight, total-w[i+1], include)  # w[i+1] 포함 X


n = 4
w = [1, 2, 4, 6]
W = 6
print("items =", w, "W =", W)
include = n*[0]
total = 0
for k in w:
    total += k
s_s(-1, 0, total, include)
