from tabnanny import verbose
from turtle import distance


inf = 1000
w = [[0, 7, 4, 6, 1], [inf, 0, inf, inf, inf],
     [inf, 2, 0, 5, inf], [inf, 3, inf, 0, inf], [inf, inf, inf, 1, 0]]

n = 5
f = set()  # e 저장
touch = n*[0]
length = n*[0]
save_length = n*[0]
vnear = -1  # 이번에 찾은 최소 정점
NoC = 0  # length 업데이트 횟수
for i in range(1, n):
    length[i] = w[0][i]  # 최초의 length는 v0부터 각 정점까지 가는 거리
    # length의 값은 v0 ~ vi까지의 최소거리임
for i in w:
    for j in i:
        if(j != inf and j != 0):
            NoC += 1

for i in range(1, n):
    min = inf
    for j in range(1, n):
        if(length[j] >= 0 and length[j] < min):
            min = length[j]
            vnear = j  # 이번에 찾은 최소거리 정점
    e = (touch[vnear], vnear)  # 각 정점으로 가는 최소거리에서의 마지막 간선
    f.add(e)
    save_length[vnear] = min  # 최소거리 저장

    for i in range(1, n):  # 업데이트
        # 각 정점에 대해 검사, v0 ~ vnear -> vi값이 기존 v0 ~ vi값보다 작은지
        if(length[vnear] + w[vnear][i] < length[i]):
            length[i] = length[vnear] + w[vnear][i]
            touch[i] = vnear
    length[vnear] = -1  # vnear이 Y집합에 들어왔음을

NoC -= len(f)
print(f)
print(save_length)
print(NoC)
