'''
우선순위 큐: FIFO가 아닌 우선순위가 높은 데이터가 먼저 나가는 형태의 자료구조, heap으로 구현

Heap: 완전이진트리 형태의 자료구조
    부모 노드와 서브 트리간 대소 관계가 성립
    중복된 값 허용

Max Heap: 부모노드 >= 자식노드
Min Heap: 부모노드 <= 자식노드

힙은 주로 배열로 구현, 편의를 위해 인덱스 1부터 시작
노드 i의 부모노드 idx: i//2
노드 i의 왼쪽 자식 노드 idx: 2*i
노드 i의 오른쪽 자식 노드 idx: 2*i + 1
'''
import heapq
from collections import defaultdict


def encode(frequency):
    heap = [[weight, [symbol, '']] for symbol, weight in frequency.items()]
    print(heap)
    heapq.heapify(heap)
    while len(heap) > 1:
        lo = heapq.heappop(heap)
        hi = heapq.heappop(heap)
        for pair in lo[1:]:
            pair[1] = '0' + pair[1]
        for pair in hi[1:]:
            pair[1] = '1' + pair[1]
        heapq.heappush(heap, [lo[0] + hi[0]] + lo[1:] + hi[1:])
    return sorted(heapq.heappop(heap)[1:], key=lambda p: (len(p[-1]), p))


data = "The frog at the bottom of the well drifts off into the great ocean"
frequency = defaultdict(int)

for symbol in data:
    frequency[symbol] += 1

huff = encode(frequency)
print("Symbol".ljust(10) + "Weight".ljust(10) + "Huffman Code")
for p in huff:
    print(p[0].ljust(10) + str(frequency[p[0]]).ljust(10) + p[1])
