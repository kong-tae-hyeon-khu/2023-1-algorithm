from audioop import maxpp
from unittest import BaseTestSuite
from xml.etree.ElementInclude import include


def promising(i, weight, profit):  # 남은 공간이 있고 확장시 bound 값이 현재 최대값보다 크면 True
    global maxp
    if(weight >= W):
        return False
    else:
        j = i+1  # i까지는 처리완료 했으니 i+1부터 검사
        bound = profit  # i번째까지 넣었던 아이템들의 p 합
        totweight = weight  # i번째까지 넣었던 아이템들의 무게 합
        while(j <= n-1 and totweight + w[j] <= W):
            totweight += w[j]
            bound += p[j]
            j += 1
        k = j  # k-1까지 검사 완료
        if(k <= n-1):  # 더 넣을 수 있는데 무게때문에 못넣을 때 잘라서 넣기
            bound += (W-totweight)*p[k] / w[k]

        return bound > maxp


def kp(i, weight, profit):
    global bestset
    global maxp

    if(weight <= W and profit > maxp):  # 현재 자신의 상태 확인 (유효한지)
        maxp = profit
        bestset = include[:]

    if(promising(i, weight, profit)):
        include[i+1] = 'yes'  # i+1 포함
        kp(i+1, weight+w[i+1], profit + p[i+1])
        include[i+1] = 'no'  # i+1 포함 X
        kp(i+1, weight, profit)


n = 4
W = 16
p = [40, 30, 50, 10]
w = [2, 5, 10, 5]
maxp = 0
include = [0, 0, 0, 0]
bestset = [0, 0, 0, 0]
kp(-1, 0, 0)
print(maxp)
print(bestset)
