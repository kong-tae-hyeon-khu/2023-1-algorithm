import queue


class Node:
    def __init__(self, level, weight, profit, include):
        self.level = level
        self.weight = weight
        self.profit = profit
        self.include = include


def kp_BFS():
    global maxProfit
    global bestset
    global maxQueSize
    global totalNode_kp_BFSNum
    q = queue.Queue()
    v = Node(-1, 0, 0, [])
    q.put(v)
    totalNode_kp_BFSNum += 1
    while(not q.empty()):
        v = q.get()

        v.include.append(1)  # 이번 노드를 가방에 넣음
        u1 = Node(v.level+1,
                  v.weight + w[v.level+1],
                  v.profit + p[v.level+1],
                  v.include[:])

        if(u1.weight <= W and u1.profit > maxProfit):
            maxProfit = u1.profit  # maxProfit이 업데이트 == bestset에 포함
            bestset = u1.include[:]
        if(compBound(u1) > maxProfit):  # 아번 노드가 유망한지 검사
            q.put(u1)

        v.include.pop()
        v.include.append(0)  # 이번 노드를 가방에 안넣음
        u2 = Node(v.level+1,
                  v.weight,
                  v.profit,
                  v.include[:])

        if(compBound(u2) > maxProfit):  # 아번 노드가 유망한지 검사
            q.put(u2)
        maxQueSize = max(q.qsize(), maxQueSize)


def compBound(u):  # bound값 계산
    global totalNode_kp_BFSNum
    totalNode_kp_BFSNum += 1
    if(u.weight >= W):
        return 0
    else:
        result = u.profit
        j = u.level + 1
        totweight = u.weight
        while(j < n and totweight + w[j] <= W):
            totweight += w[j]
            result += p[j]
            j += 1
        k = j
        if(k < n):
            result += (W-totweight) * p[k]/w[k]
        return result


maxQueSize = 0
totalNode_kp_BFSNum = 0
n = 4
W = 16
p = [40, 30, 50, 10]
w = [2, 5, 10, 5]
include = [0] * n
maxProfit = 0
bestset = n*[0]
kp_BFS()
print(bestset)
print(maxQueSize)
print(totalNode_kp_BFSNum)
