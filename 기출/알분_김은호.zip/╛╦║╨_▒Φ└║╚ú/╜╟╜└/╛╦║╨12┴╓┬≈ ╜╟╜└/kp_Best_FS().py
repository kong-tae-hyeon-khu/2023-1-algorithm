from queue import PriorityQueue


class Node_kp_Best_FS:
    def __init__(self, level, weight, profit, bound, include):
        self.level = level
        self.weight = weight
        self.profit = profit
        self.bound = bound
        self.include = include

    def __lt__(self, other):
        return self.bound < other.bound


def compBound(u):  # 이전과 같음
    if(u.weight >= W):
        return 0
    else:
        result = u.profit
        j = u.level + 1
        totweight = u.weight
        while(j < n and totweight + w[j] <= W):
            totweight += w[j]
            result += p[j]
            j += 1
        k = j
        if(k < n):
            result += (W-totweight) * p[k]/w[k]
        return -result  # heap이 minheap이어서 bound를 계산하여 -을 리턴


def kp_Best_FS():
    global maxProfit, bestset
    temp = n * [0]
    v = Node_kp_Best_FS(-1, 0, 0, 0.0, temp)
    q = PriorityQueue()
    v.bound = compBound(v)
    q.put(v)
    while(not q.empty()):
        v = q.get()
        if(v.bound < maxProfit):  # 비교를 <으로 수행, bound값이 음수여서 반대방향
            u = Node_kp_Best_FS(
                v.level+1, v.weight +
                w[v.level+1], v.profit+p[v.level+1], 0.0, v.include[:]
            )
            u.bound = compBound(u)
            u.include[u.level] = 1

            if(u.weight <= W and u.profit > maxProfit):
                maxProfit = -u.profit  # 음수 유의
                bestset = u.include[:]

            if(u.bound < maxProfit):
                q.put(u)

            u = Node_kp_Best_FS(
                v.level+1, v.weight, v.profit, 0.0, v.include[:]
            )
            u.bound = compBound(u)
            u.include[u.level] = 0

            if(u.bound < maxProfit):
                q.put(u)


n = 4
W = 16
p = [40, 30, 50, 10]
w = [2, 5, 10, 5]
include = [0] * n
maxProfit = 0
bestset = n*[0]
kp_Best_FS()
print(bestset)
print(maxProfit)
