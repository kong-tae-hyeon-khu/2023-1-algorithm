from math import dist
from pprint import pprint

inf = 1000
w = [
    [0,   1,   3,   inf,   inf],
    [1,   0,   3,   6,     inf],
    [3,   3,   0,   4,       2],
    [inf, 6,   4,   0,       5],
    [inf, inf, 2,   5,       0]
]
F = set()


# distance[i] : 현재 V의 정점들에서 V-R의 정점 v[i]로 갈 수 있는 최소거리, i번 째가 -1이면 vi는 이미 V에 존재
# nearest[i] : nearset[3] = 1이면 v3과 가장 가까운 인접 정점은 v1이다.
def prim(w, F):
    n = len(w)
    nearest = [0]*n
    distance = [0]*n
    vnear = -1
    # 두 번째 시행이라고 가정 (V에는 v0, v1이 있다)
    for i in range(1, n):
        distance[i] = w[0][i]  # 최초 거리 저장(V에 v0만 있을 때, v0에서 각 정점까지의 거리)

    for k in range(n-1):  # n-1번 수행, 1부터
        minnum = inf
        for i in range(1, n):
            # V에 없는 노드(v2 ~ v4)중 V와 가장 가까운 것 찾기, 이 경우 i = 2
            if(distance[i] >= 0 and distance[i] < minnum):
                minnum = distance[i]
                vnear = i
        e = (vnear, nearest[vnear])  # 이번에 찾은 간선
        distance[vnear] = -1  # 찾은 노드를 V집합에 추가, 이렇게하면 위 조건문에 걸리지 않아 건너뛰게 된다.
        F.add(e)
        for i in range(1, n):
            if(w[vnear][i] < distance[i]):  # 이번에 들어온 정점을 이용하여 distance 업데이트
                distance[i] = w[i][vnear]
                nearest[i] = vnear  # 새로운 들어온 값으로 neaaarset 업데이트


prim(w, F)
print(F)
