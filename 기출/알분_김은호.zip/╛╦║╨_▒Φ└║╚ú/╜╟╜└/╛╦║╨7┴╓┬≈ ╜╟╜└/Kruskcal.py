parent = dict()
rank = dict()


def make_singleton_set(v):  # 처음에 서로소인 n개의 부분집합 만듬
    parent[v] = v  # {'A' = A, ...}
    rank[v] = 1


def find(v):
    if parent[v] != v:
        parent[v] = find(parent[v])
    return parent[v]
# parent['B'] = A이면 parent[B] = find(A)가 되어 결국 A를 반환


def union(r1, r2):  # 원소의 개수가 작은 것을 큰 쪽으로 합침
    if r1 != r2:
        if rank[r1] > rank[r2]:
            parent[r2] = r1  # 'B'가 'A'로 합쳐지면 이제 parent['B'] = A가 됨
            rank[r1] += rank[r2]
        else:
            parent[r1] = r2
            if rank[r1] == rank[r2]:
                rank[r2] += rank[r1]


# graph : dictionary
# vertex : list
# edges : set()
def kruskal(graph):
    vertex = graph['vertices']
    edge = list(sorted(graph['edges']))  # edges집합을 정렬된 edge 리스트로 바꿈
    F = set()  # 간선 저장 집합
    for i in range(len(vertex)):  # 최초로 서로소인 부분집합으로 다 나눔
        make_singleton_set(vertex[i])

    i = 0
    while(len(F) < len(vertex)-1):  # F의 크기가 n-1일 때까지 반복
        (a, b) = (edge[i][1], edge[i][2])
        p = find(a)
        q = find(b)
        if(p != q):
            union(p, q)
            F.add(edge[i])
        i += 1

    return F


graph = {
    'vertices': ['A', 'B', 'C', 'D', 'E'],
    'edges': set([
        (1, 'A', 'B'),
        (3, 'A', 'C'),
        (3, 'B', 'C'),
        (6, 'B', 'D'),
        (4, 'C', 'D'),
        (2, 'C', 'E'),
        (5, 'D', 'E'), ])
}

mst = kruskal(graph)
print(mst)
