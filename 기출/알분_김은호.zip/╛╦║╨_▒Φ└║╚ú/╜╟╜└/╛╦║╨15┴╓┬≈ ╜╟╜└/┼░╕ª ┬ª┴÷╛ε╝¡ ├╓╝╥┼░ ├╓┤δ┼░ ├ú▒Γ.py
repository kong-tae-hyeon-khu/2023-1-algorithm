def find_both(S):
    if(S[0] < S[1]):
        small = S[0]
        large = S[1]
    else:
        small = S[1]
        large = S[0]

    for i in range(2, len(S)-1, 2):
        if(S[i] < S[i+1]):  # pair중 오른쪽이 더 클 때
            if(S[i] < small):
                small = S[i]
            if(S[i+1] > large):
                large = S[i+1]
        else:  # pair 중 왼쪽이 더 클 때
            if S[i] > large:
                large = S[i]
            if(S[i+1] < small):
                small = S[i+1]

    return large, small


S = [2, 6, 4, 8, 10, 3, 7, 1, 5, 9]

large, small = find_both(S)
print(large, small)
