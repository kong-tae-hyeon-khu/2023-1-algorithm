from cmath import inf
import numpy as np
infi = 1000

'''
D(k)[i][j] = min(D(k-1)[i][j], D(k-1)[i][k] + D(k-1)[k][j])
'''


def floyd1(g, n):  # g = 제일 초기 가중치 그래프(인접 행렬), n : 정점의 수
    d = g
    for k in range(0, n):  # Dk에서 k를 정하는 역할
        for i in range(0, n):  # k일 때의 모든 경우의 수를 구함
            for j in range(0, n):
                d[i][j] = min(d[i][j], d[i][k] + d[k][j])

    g = d


'''
k = 1일 때 D[i][j]를 모두 구함
그 후 k = 2일 때를 k = 1일 때의 계산 결과를 가지고 구함
'''

g = np.array([
    [0, 1, infi, 1, 5],
    [9, 0, 3, 2, infi],
    [infi, infi, 0, 4, infi],
    [infi, infi, 2, 0, 3],
    [3, infi, infi, infi, 0]
]
)

print(g)

print()

floyd1(g, 5)

print(g)
