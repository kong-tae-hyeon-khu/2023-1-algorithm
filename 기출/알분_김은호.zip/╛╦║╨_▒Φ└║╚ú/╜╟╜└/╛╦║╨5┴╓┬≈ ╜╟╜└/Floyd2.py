
import numpy as np
infi = 1000

'''
D(k)[i][j] = min(D(k-1)[i][j], D(k-1)[i][k] + D(k-1)[k][j])
'''


def floyd2(g, n, p):  # n : 정점의 수
    d = g
    for k in range(0, n):  # k를 정하는 역할
        for i in range(0, n):
            for j in range(0, n):
                if(d[i][k] + d[k][j] < d[i][j]):    # 현재 d[i][j]값(기존에 vi에서 vj로 가는 방법 = k를 거치지 않는 방법))이 
                                                    # k를 거쳐서 가는 값보다 크면
                                                    # min(d[i][k], d[i][k] + d[k][j])와 같은데 p[i][j] = k를 위해서 이렇게 구분
                    p[i][j] = k                   
                    d[i][j] = d[i][k] + d[k][j]  # 더 작은 값으로 업데이트

    g = d


'''
k = 1일 때 D[i][j]를 모두 구함
그 후 k = 2일 때를 k = 1일 때의 계산 결과를 가지고 구함
'''


def path(p, i, j):
    result = ''         # 이 경우엔 정점이 0부터 시작하여 -1일 때 정점을 거치지 않는 것
    if(p[i][j] != -1):  # 0이면 정점을 거치지 않고 바로 가는 것이 제일 빠름
        result += str(path(p, i, p[i][j]))  # vi에서 vk로 가는 길
        result += 'v' + str(p[i][j])  # vk
        result += str(path(p, p[i][j], j))  # vk에서 vj로 가는 길
    return result


g = np.array([
    [0, 1, infi, 1, 5],
    [9, 0, 3, 2, infi],
    [infi, infi, 0, 4, infi],
    [infi, infi, 2, 0, 3],
    [3, infi, infi, infi, 0]
]
)
p = np.array([  # 정점 시작을 0으로 해서 구분하기 위해 -1로 초기화함
    [-1, -1, -1, -1, -1],
    [-1, -1, -1, -1, -1],
    [-1, -1, -1, -1, -1],
    [-1, -1, -1, -1, -1],
    [-1, -1, -1, -1, -1]
])


print(g)

print()

floyd2(g, 5, p)

print(g)
print()
print(p)
print()
print(path(p, 4, 2))
