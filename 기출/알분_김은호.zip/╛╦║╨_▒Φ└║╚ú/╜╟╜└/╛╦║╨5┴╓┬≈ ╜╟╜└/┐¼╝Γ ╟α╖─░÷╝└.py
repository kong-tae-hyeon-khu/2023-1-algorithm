import numpy as np


def order(p, i, j):  # i < j
    result = ''  # 결과값 저장
    if(i == j):
        return ' A' + str(i) + ' '
    else:
        k = p[i][j]
        result += '('
        result += order(p, i, k)  # Ai에서 Ak까지의 최적 경우
        result += order(p, k+1, j)  # Ak+1에서 Aj까지의 최적 경우
        result += ')'
    return result


# 1열 1행부터 시작한다고 가정
# n: 행렬의 개수 d[i-1] * d[i] : i번째 행렬의 크기, p : 최적순서 저장 행렬, m : 최소곱셉 저장 행렬
def minmult(n, d, p, m):
    '''
    행렬을 초기화할 때 다 0으로 해서 필요없는 부분
    for i in range(1, n+1):
        m[i][i] = 0
    '''
    for diag in range(1, n):  # 대각, 이전에 계산한 대각을 통해 그 위의 대각을 계산
        for i in range(1, n-diag+1):  # 한 대각에 대해 n-diag 행까지 연산
            j = i + diag
            for k in range(i, j):  # Ai ~ Aj중 최소로 곱하는 연산 찾는 과정
                compareValue = m[i][k] + m[k+1][j] + d[i-1]*d[k]*d[j]
                # m[i][j]가 0이면 m[i][j]가 최초로 단위연산에 할당되는 순간임
                if(compareValue < m[i][j] or m[i][j] == 0):
                    p[i][j] = k
                    m[i][j] = compareValue


'''
대각 1은 행렬 두 개의 곱 - M[1][2] 등 (A1 A2, A2 A3 등)
대각 2는 행렬 세 개의 곱 - M[2][4] 등
... 
대각 n-1은 행렬 n개의 곱 = M[1][n]
목표는 행렬 M[1][n] = M[1][k] + M[k+1[n]인 k를 찾는 것, 이를 위해 모든 대각을 구해야 함


'''


def main():
    d = [5, 2, 3, 4, 6, 7, 8]
    n = len(d) - 1

    m = np.zeros((n+1, n+1), dtype=int)  # numpy로 행렬을 0으로 초기화, dtype: 0의 타입 지정
    p = np.zeros((n+1, n+1), dtype=int)

    minmult(n, d, p, m)
    print(m)
    print()

    print(p)
    print()

    print(order(p, 1, 6))


main()
