import numpy as np


def bin1(n, k):  # 분할 정복 이항계수
    if(k == 0 or n == k):
        return 1
    else:
        return bin1(n-1, k-1) + bin1(n-1, k)


def bin2(n, k):
    b = np.zeros((n+1, k+1), dtype=int)
    for i in range(0, n+1):
        for j in range(0, min(i, k)+1):
            if(j == 0 or j == i):
                b[i][j] = 1
            else:
                b[i][j] = b[i-1][j-1] + b[i-1][j]
    return b[n][k]


print('bin 1 : ' + str(bin1(10, 5)))
print()
print('bin 2 : ' + str(bin2(10, 5)))
