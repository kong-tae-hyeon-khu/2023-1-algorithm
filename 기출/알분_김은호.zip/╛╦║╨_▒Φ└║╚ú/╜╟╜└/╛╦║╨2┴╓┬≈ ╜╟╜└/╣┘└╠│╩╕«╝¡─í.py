def bS_recursion(arr, item, low, high):
    if(low > high):
        return -1

    mid = (low + high) // 2

    if(arr[mid] == item):
        return mid
    elif(arr[mid] > item):
        return bS_recursion(arr, item, low, mid-1)
    else:
        return bS_recursion(arr, item, mid+1, high)


def bS(arr, item):
    low = 0
    high = len(arr) - 1
    while(low <= high):
        mid = (low + high) // 2
        if(arr[mid] == item):
            return mid
        elif(arr[mid] > item):
            high = mid - 1
        else:
            low = mid+1
    return -1
