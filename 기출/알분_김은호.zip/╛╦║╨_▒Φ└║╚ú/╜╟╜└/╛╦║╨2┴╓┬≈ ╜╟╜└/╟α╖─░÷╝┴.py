def canMult(A, B):
    if(len(A) > 0 and len(B) > 0):
        if(len(A[0] == len(B))):  # 앞 행렬 열의 수 == 뒤 행렬 행의 수 이면 가능
            return True
    return False


def matrixMul(A, B):
    if(canMult(A, B)):
        row = len(A)
        col = len(B[0])  # row = 행, col = 열
        C = [[0] * col for i in range(row)]  # row * col 행렬 생성

        for i in range(row):
            for j in range(col):
                for k in range(len(B)):
                    C[i][j] += A[i][k]*B[k][j]
        return C
    return "행렬 곱셈 연산을 할 수 없습니다."
