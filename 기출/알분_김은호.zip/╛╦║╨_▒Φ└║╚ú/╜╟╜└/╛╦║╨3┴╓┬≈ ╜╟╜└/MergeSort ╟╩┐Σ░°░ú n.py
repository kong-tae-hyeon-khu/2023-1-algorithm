'''
필요 공간이 n인 Merge Sort는 2n처럼 처음에 두 개로 분할하지 않음
합치는 과정에서 필요한 크기만큼 할당 받음
원본을 다룸
원본의 반씩을 나눠 따로 정렬하고, 합치는 과정에서 총 길이 만큼의 새로운
리스틀르 할당하고 거기에 비교하여 정렬 후, 원본에 다시 복사
merge가 끝나면 임시 리스트가 할당받은 메모리는 반납
즉 최종적으로 할당 받을 리스트 크기만큼이 필요, n
비재귀 MergeSort와 비슷한 원리임
'''

def mergeSort(arr, low, high): # high = len(arr) - 1
    mid = 0
    if(low < high):
        mid = (low + high) // 2
        mergeSort(arr, low, mid)
        mergeSort(arr, mid+1, high)
        merge(arr, low, mid, high)

def merge(arr, low, mid, high):
    temp = [0] * (high - low + 1)
    i = low #왼쪽 배열 시작
    j = mid+1 #오른쪽 배열 시작
    k = 0
    while(i <= mid and j <= high):
        if(arr[i] < arr[j]):
            temp[k] = arr[i]
            i += 1
        else:
            temp[k] = arr[j]
            j += 1
        k += 1
    
    while(i <= mid):
        temp[k] = arr[i]
        i+=1; k+=1
    while(j <= high):
        temp[k] = arr[j]
        j+=1; k+=1
    arr[low:high+1] = temp[0:k]

arr = [3,5,2,9,10,14,4,8]
mergeSort(arr, 0, len(arr)-1)
print(arr)

'''
2n - 두 개의 임시 배열을 만들고 합칠 때 두 개의 임시 배열을 비교하며 arr에 복사
n - arr 자체를 반반 나누어 반씩 정렬, 임시배열에 그 반씩 나눈 배열을 비교하여 복사, 
    마지막에 임시배열 전체를 arr에 복사
'''