'''
쪼개는 단위를 1부터 시작하여 2 -> 4 -> ... n/2까지함
즉 쪼개는 단위가 k일 때 한 번 돌때 두 개의 k길이의 배열을 정렬하여 temp라는 임시 리스트에 저장하고, 원래 리스트에 복사 
한 번 돌면 원래 리스트(arr)에 2k 단위로 정렬이 됨
다음 번 돌 때(쪼개는 단위가 2배 증가할 때) 다시 정렬
결국 최종적으로 n/2개, n/2개씩 나뉘어 지고 정렬
'''


def norecursion_merge_sort(arr):
    left = rstart = rend = 0
    # left: 쪼개는 첫 번째 배열의 시작지점(왼쪽배열 스타트지점)
    # rstart: 쪼개는 두 번쨰 배열의 시작지점(오른쪽 배열 스타트 지점, rstart-1이 왼쪽 배열의 마지막 지점)
    # rend : 오른쪽 배열의 끝지점
    k = 1  # 분할할 크기
    num = len(arr)
    temp = []  # 이번 루프에 정렬되는 아이템 저장
    size = 0
    while(k < num):
        left = 0
        while(left + k < num):  # k개의 배열 2개를 만들 수 없을 때까지
            rstart = left + k
            rend = rstart + k
            if(rend > num):
                rend = num
            i = left
            j = rstart

            while(i < rstart and j < rend):
                if(arr[i] <= arr[j]):
                    temp.append(arr[i])
                    i += 1
                else:
                    temp.append(arr[j])
                    j += 1
                # print('필요한 크기 1 추가')
                size += 1

            while(i < rstart):  # 왼쪽 배열이 남음 -> 왼쪽 배열이 다 클 때
                temp.append(arr[i])
                # print('필요한 크기 1 추가')
                i += 1
                size += 1
            while(j < rend):  # 오른쪽 배열이 남음
                temp.append(arr[j])
                # print('필요한 크기 1 추가')
                j += 1
                size += 1

            spoint = left  # 이번 left지점(이번 쪼개기 시작지점)부터 끝지점까지 arr에 복사
            while(spoint < rend):
                arr[spoint] = temp[spoint]
                spoint += 1
                # 2k 만큼 정렬이 됨
            left += k * 2  # 시작지점 옮기기

        k *= 2  # k 크기를 늘려서 arr 분할하고 정렬
        if(k >= num):
            pass
        else:
            temp.clear()
    return arr


arr = [8, 3, 15, 2, 9, 1, 5, 7, 4, 16, 10, 11, 12, 13, 6, 14]
arr, size = norecursion_merge_sort(arr)
print(arr)
print('필요한 크기 : ' + str(size))
