'''
분할을 할 때 새로운 배열 left, right를 만들어 저장(최초로 만드는 크기 n/2 2개 -> n)
왼쪽배열 mergeSort가 끝나면 왼쪽 메모리는 반환
오른쪽 mergeSort를 하는데 필요한 메모리: n/2개 -> n/4개 ...
즉 n + n/2 + .. + 1 = 2n
'''

def mergeSort(n, arr):
    h = n//2; m = n-h # h: 왼쪽배열크기 m:오른쪽 배열 크기
    leftarr = [0] * h
    rightarr = [0] * m
    
    if(n > 1):
        leftarr = arr[:h]
        rightarr = arr[h:]
        mergeSort(h, leftarr)
        mergeSort(m, rightarr)
        merge(h,m,leftarr,rightarr,arr)

def merge(h, m, leftarr, rightarr, arr):
    i = j = k = 0
    while(i < h and j < m):
        if(leftarr[i] < rightarr[j]):
            arr[k] = leftarr[i]
            i += 1
        else:
            arr[k] = rightarr[j]
            j += 1
        k += 1
    while(i < h):
        arr[k] = leftarr[i]
        k += 1; i += 1
    while(j < m):
        arr[k] = rightarr[j]
        k += 1; j += 1

arr = [3,5,2,9,10,14,4,8]
mergeSort(len(arr), arr)
print(arr)