
# 1부터 (11 - 1) 까지 2개의 간격으로 증가
for i in range(1, 11, 2):
    print(i)
