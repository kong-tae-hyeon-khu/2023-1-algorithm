from random import *

count = 0  # 비교횟수


def quickSort(arr, low, high) -> None:
    if(high > low):
        pivotPoint = partition(arr, low, high)
        quickSort(arr, low, pivotPoint-1)
        quickSort(arr, pivotPoint+1, high)

# pivot을 기준으로 작은 것은 왼쪽에, 큰 것은 오른쪽에 놓고
# pivot은 그 가운데에 놓은 후 가운데 위치 반환


def partition(arr, low, high) -> int:
    j = low
    pivotItem = arr[low]
    for i in range(low+1, high+1):
        if(arr[i] < pivotItem):
            j += 1
            arr[i], arr[j] = arr[j], arr[i]
    arr[low], arr[j] = arr[j], arr[low]

    return j  # pivotpoint 반환


def make_random_list(n):  # 난수리스트 생성
    arr = []
    for i in range(n):
        num = randint(0, n)
        arr.append(num)
    return arr


def countZero():  # 비교횟수 초기화
    global count
    count = 0
