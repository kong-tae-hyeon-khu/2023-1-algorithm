import math


def prod(a, b):
    n = max(len(str(a), len(str(b)))) # 두 수중의 자릿수가 큰 것
    if(a == 0 or b == 0):
        return 0
    elif(n <= 2):
        return a * b  # threshhold = 2
    else:
        m = math.floor(n/2) # 바닥 함수
        x = a // 10**m
        y = a % 10**m

        w = b // 10**m
        z = b % 10**m
        return prod(x, w) * 10**(2*m) + (prod(x, z) + prod(w, y)) * 10**m + prod(y, z)
