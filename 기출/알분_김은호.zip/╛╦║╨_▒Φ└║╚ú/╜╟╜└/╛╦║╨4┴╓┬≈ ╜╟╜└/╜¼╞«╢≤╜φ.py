from numpy import *
def strassen(n, A, B ,C):
    threshold = 2 # 임계점
    A11 = array([[A[row][col] for col in range(n//2)] for row in range(n//2)])
    A12 = array([[A[row][col] for col in range(n//2, n)] for row in range(n//2)])
    A21 = array([[A[row][col] for col in range(n//2)] for row in range(n//2, n)])
    A22 = array([[A[row][col] for col in range(n//2, n)] for row in range(n//2, n)])

    B11 = array([[B[row][col] for col in range(n//2)] for row in range(n//2)])
    B12 = array([[B[row][col] for col in range(n//2, n)] for row in range(n//2)])
    B21 = array([[B[row][col] for col in range(n//2)] for row in range(n//2, n)])
    B22 = array([[B[row][col] for col in range(n//2, n)] for row in range(n//2, n)])

    if(n <= threshold): # 임계점 이하면 그냥 곱하는게 더 성능이 좋음
        C = array(A) @ array(B)
    else:
        M1 = M2 = M3 = M4 = M5 = M6 = M7 = array([])
        M1 = strassen(n//2, (A11 + A22), (B11 + B22), M1)
        M2 = strassen(n//2, (A21+A22), B11, M2)
        M3 = strassen(n//2, A11, (B12 - B22), M3)
        M4 = strassen(n//2, A22, (B21 - B11), M4)
        M5 = strassen(n//2, (A11 + A12), B22, M5)
        M6 = strassen(n//2, (A21 - A11), (B11 + B12), M6)
        M7 = strassen(n//2, (A12 - A22), (B21 + B22), M7)

        # hstack : 행렬 가로로 합치기 | vstack : 행렬 세로로 합치기
        C = vstack([hstack([M1+M4-M5+M7], M3+M5)], hstack([M2+M4], [M1+M3-M2+M6])) 
    return C