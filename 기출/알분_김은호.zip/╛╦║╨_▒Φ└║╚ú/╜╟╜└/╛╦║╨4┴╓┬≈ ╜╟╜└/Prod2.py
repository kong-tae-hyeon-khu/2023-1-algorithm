import math


def prod2(a, b):  # 큰 정수곱셈 2로 구현
    n = max(len(str(a)), len(str(b)))
    if(a == 0 or b == 0):
        return 0
    elif(n <= 2):
        return a * b
    else:
        m = math.floor(n/2)  # 바닥함수
        x = a // 10**m
        y = a % 10**m

        w = b // 10**m
        z = b % 10**m

        r = prod2(x+y, w+z)
        p = prod2(x, w)
        q = prod2(y, z)
        return p * 10**(2*m) + (r-p-q)*10**m + q
