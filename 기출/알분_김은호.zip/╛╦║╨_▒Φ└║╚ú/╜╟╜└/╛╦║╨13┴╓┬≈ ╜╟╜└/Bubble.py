def bubbleSort(arr):
    n = len(arr)

    for i in range(n, -1, -1):
        for j in range(1, i+1):
            if(arr[j-1] > arr[j]):
                arr[j-1], arr[j] = arr[j], arr[j-1]
