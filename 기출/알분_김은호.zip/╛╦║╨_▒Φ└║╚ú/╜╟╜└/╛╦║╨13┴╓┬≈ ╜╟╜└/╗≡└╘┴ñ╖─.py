'''
이미 정렬된 배열에서 적절한 자리로 삽입
1번째 인덱스부터 시작

i번째 인덱스를 적절한 자리로 삽입 ( 0 ~ i-1은 이미 정렬 완료)
1. i-1부터 검사, j = i - 1
2. j번째가 i번째 데이터보다 작으면 j번째 오른
'''


def insertionSort(n, arr):
    for i in range(1, n):  # 두 번째 항목부터 시작
        x = arr[i]
        j = i-1
        while(j >= 0 and arr[j] > x):
            arr[j+1] = arr[j]  # j번째 항목이 타겟보다 크면 오른쪽으로 이동
            j -= 1
        arr[j+1] = x  # j번째가 x보다 작으므로 j번째 오른쪽에 x 삽입


arr = [3, 2, 5, 7, 1, 9, 4, 6, 8]

insertionSort(len(arr), arr)
print(arr)
