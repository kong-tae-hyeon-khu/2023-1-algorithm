class List:
    def __init__(self, arr) -> None:
        self.data = arr[:]
        self.n = len(arr)

    def insertionSort(self):
        for i in range(1, self.n):
            x = self.data[i]
            j = i-1
            while(j >= 0 and self.data[j] > x):
                self.data[j+1] = self.data[j]
                j -= 1
            self.data[j+1] = x


arr = [3, 2, 5, 7, 1, 9, 4, 6, 8]

li = List(arr)
li.insertionSort()
print(li.data)
