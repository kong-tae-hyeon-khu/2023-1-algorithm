from tkinter.messagebox import NO
from tkinter.tix import Tree

from numpy import isin


class Node:
    def __init__(self, data):
        self.l_child = None
        self.r_child = None
        self.data = data


def bin_search_tree_insert(root, node):
    if root is None:
        root = node
    else:
        if(root.data > node.data):
            if root.l_child is None:  # 이 식 없이 재귀호출하여 root is None root = node로 처리하려했는데 그러면 자식으로 인식을 못했음
                root.l_child = node
            else:
                bin_search_tree_insert(root.l_child, node)
        else:
            if root.r_child is None:
                root.r_child = node
            else:
                bin_search_tree_insert(root.r_child, node)


def bin_search_tree_delete(root, node):
    # 1. node 데이터가 트리에 있는지 검사
    # 2. 그 node가 자식 몇개 가지는지 검사
    is_search = False
    curr_node = root
    parent = root
    while(curr_node is not None):
        if(curr_node.data == node.data):
            is_search = True
            break
        elif(curr_node.data > node.data):
            parent = curr_node
            curr_node = curr_node.l_child
        else:
            parent = curr_node
            curr_node = curr_node.r_child
    if is_search == False:
        return False

    # 삭제하는 노드가 leaf
    if curr_node.l_child is None and curr_node.r_child is None:
        if node.data < parent.data:
            parent.l_child = None
        else:
            parent.r_child = None

    # 삭제하는 노드의 자식이 하나(왼쪽)
    if curr_node.l_child is not None and curr_node.r_child is None:
        if(node.data < parent.data):
            parent.l_child = curr_node.l_child
        else:
            parent.r_child = curr_node.l_child

    # 삭제하는 노드의 자식이 하나(오른쪽)
    if curr_node.l_child is None and curr_node.r_child is not None:
        if(node.data < parent.data):
            parent.l_child = curr_node.r_child
        else:
            parent.r_cjo
            d = curr_node.r_child

    # 삭제하는 노드의 자식이 두 개
    if curr_node.l_child is not None and curr_node.r_child is not None:
        changenode = curr_node.r_child
        changenode_parent = curr_node.r_child
        while changenode.l_child is not None:
            changenode_parent = changenode
            changenode = changenode.l_child  # 오른쪽에서 가장 작은 것 찾기

        if(changenode.r_child is not None):  # 오른쪽에서 가장 작은 노드의 오른쪽 자식 관리
            changenode_parent.l_child = changenode.r_child
        else:
            changenode_parent.l_child = None

        if node.data < parent.data:
            parent.l_child = changenode
            changenode.l_child = curr_node.l_child
            changenode.r_child = curr_node.r_child
        else:
            parent.r_child = changenode
            changenode.l_child = curr_node.l_child
            changenode.r_child = curr_node.r_child
    return True


def preOrder(root):
    if(root is not None):
        print(root.data)
        preOrder(root.l_child)
        preOrder(root.r_child)


def inOrder(root):
    if(root is not None):
        inOrder(root.l_child)
        print(root.data)
        inOrder(root.r_child)


r = Node(7)

bin_search_tree_insert(r, Node(9))

bin_search_tree_insert(r, Node(11))

bin_search_tree_insert(r, Node(10))
preOrder(r)
