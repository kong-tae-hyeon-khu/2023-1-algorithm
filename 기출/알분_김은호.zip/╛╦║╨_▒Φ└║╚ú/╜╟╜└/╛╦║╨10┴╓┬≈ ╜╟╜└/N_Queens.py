count = 0  # 생성한 상태공간트리의 총 노드 수
result = 0  # 해의 총 개수


def promising(i, col):
    k = 0
    switch = True
    while(k < i and switch):
        if(col[i] == col[k] or abs(col[i] - col[k]) == i - k):  # 같은 열 || 대각선내에 위치하는지 검사
            switch = False
        k += 1
    global count
    count += 1
    return switch

# 0행부터 n-1행까지 진행하므로 행은 따로 검사할 필요가 없음(어차피 다음 행에는 여왕이 없으므로)


def queens(n, i, col):
    if(promising(i, col)):  # 노드 하나 생성 & 그 노드가 적합한지 판정
        if(i == n-1):  # 결과 하나 생성
            global result
            result += 1
            print(col)
        else:  # 그 다음 행의 열들의 promising 검사
            for j in range(0, n):
                col[i+1] = j
                queens(n, i+1, col)


def main2():

    n = 7
    col = n*[0]
    print('-------------------- 문제2 --------------------')
    print('해집합')
    queens(n, -1, col)
    print('생성한 상태공간트리의 총 노드 수:', count)
    print('해의 총 개수:', result)
