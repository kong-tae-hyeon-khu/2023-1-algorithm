from queue import Queue
from queue import PriorityQueue


class Node_kp_BFS:
    def __init__(self, level, weight, profit, include):
        self.level = level
        self.weight = weight
        self.profit = profit
        self.include = include


class Node_kp_Best_FS:
    def __init__(self, level, weight, profit, bound, include):
        self.level = level
        self.weight = weight
        self.profit = profit
        self.bound = bound
        self.include = include

    def __lt__(self, other):  # 대소 관계 비교 지정
        return self.bound < other.bound


def main1():

    def kp_BFS():
        nonlocal maxProfit
        nonlocal bestset
        nonlocal maxQueSize
        nonlocal totalNode_kp_BFSNum
        q = Queue()
        v = Node_kp_BFS(-1, 0, 0, [])
        q.put(v)
        totalNode_kp_BFSNum += 1  # 최초로 만들어진 노드
        # Node_kp_BFS는 따로 설정하지 않으면 deepcopy가 안되어서 put할 때마다 새로 선언을 해줘야 하는듯함.
        while(not q.empty()):
            v = q.get()

            v.include.append(1)  # 이번 노드가 포함
            u1 = Node_kp_BFS(v.level+1,  # 왼쪽, 포함
                             v.weight + w[v.level+1],
                             v.profit + p[v.level+1],
                             v.include[:])

            if(u1.weight <= W and u1.profit > maxProfit):
                maxProfit = u1.profit  # maxProfit이 업데이트 == bestset에 포함
                bestset = u1.include[:]
            if(compBound(u1) > maxProfit):  # 아직 가능성이 있으면 put
                q.put(u1)

            v.include.pop()
            v.include.append(0)  # 이번 노드는 포함 X
            u2 = Node_kp_BFS(v.level+1,  # 오른쪽, 포함 X
                             v.weight,
                             v.profit,
                             v.include[:])

            if(compBound(u2) > maxProfit):  # 아직 가능성이 있으면 put
                q.put(u2)
            maxQueSize = max(q.qsize(), maxQueSize)

    def compBound(u):
        nonlocal totalNode_kp_BFSNum
        totalNode_kp_BFSNum += 1  # Bound를 계산함 == 노드가 하나 만들어짐
        if(u.weight >= W):
            return 0
        else:
            result = u.profit
            j = u.level + 1
            totweight = u.weight
            while(j < n and totweight + w[j] <= W):  # 다 넣을 수 있을 때까지 넣기
                totweight += w[j]
                result += p[j]
                j += 1
            k = j
            if(k < n):  # 짤라서 넣기
                result += (W-totweight) * p[k]/w[k]
            return result

    maxQueSize = 0
    totalNode_kp_BFSNum = 0
    n = 4
    W = 6
    p = [30, 28, 18, 20]
    w = [3, 4, 3, 5]
    include = [0] * n
    maxProfit = 0
    bestset = n*[0]
    kp_BFS()
    print('#------------------문제1------------------')
    print('답:', bestset)
    print('큐 내의 최대 원소 수:', maxQueSize)
    print('상태공간트리의 총 노드의 개수:', totalNode_kp_BFSNum)

#-----------------------------------------문제2-----------------------------------------#


def main2():
    def compBound_Best(u):
        if(u.weight >= W):
            return 0
        else:
            result = u.profit
            j = u.level + 1
            totweight = u.weight
            while(j < n and totweight + w[j] <= W):
                totweight += w[j]
                result += p[j]
                j += 1
            k = j
            if(k < n):
                result += (W-totweight) * p[k]/w[k]
            # heap이 minheap이라 bound를 계산하여 -를 하여 리턴한다. 비교를 < maxProfit으로 수행한다.
            return -result

    def kp_Best_FS():
        nonlocal maxProfit, bestset
        temp = n * [0]
        v = Node_kp_Best_FS(-1, 0, 0, 0.0, temp)
        q = PriorityQueue()
        v.bound = compBound_Best(v)
        q.put(v)
        while(not q.empty()):
            v = q.get()
            if(v.bound < maxProfit):  # 비교를 < maxProfit으로 수행한다.
                u = Node_kp_Best_FS(
                    v.level+1, v.weight +
                    w[v.level+1], v.profit+p[v.level+1], 0.0, v.include[:]
                )
                u.bound = compBound_Best(u)
                u.include[u.level] = 1  # 포함될 때

                if(u.weight <= W and u.profit > maxProfit):
                    maxProfit = -u.profit  # minheap이라 -를 앞에 붙임
                    bestset = u.include[:]

                if(u.bound < maxProfit):  # 아직 가능성 있으면 put
                    q.put(u)

                u = Node_kp_Best_FS(
                    v.level+1, v.weight, v.profit, 0.0, v.include[:]
                )
                u.bound = compBound_Best(u)
                u.include[u.level] = 0  # 포함되지 않을 때

                if(u.bound < maxProfit):  # 아직 가능성 있으면 put
                    q.put(u)
    n = 4
    W = 16
    p = [40, 30, 50, 10]
    w = [2, 5, 10, 5]
    include = [0] * n
    maxProfit = 0
    bestset = n*[0]
    kp_Best_FS()
    print('#------------------문제2------------------')
    print('답:', bestset)
    print('Max Profit:', maxProfit)


main1()
print()
main2()
