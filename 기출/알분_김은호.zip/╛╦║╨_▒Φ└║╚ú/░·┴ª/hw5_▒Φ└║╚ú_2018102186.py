import numpy as np

#---------------------------------------------문제 1 모듈 ----------------------------------------------#


class Node:  # Node 클래스
    def __init__(self, data):
        self.l_child = None
        self.r_child = None
        self.data = data


def tree(key, r, i, j):  # i에서 j로의 Optical Tree 생성
    k = r[i][j]  # i에서 j로 최적으로 갈 때의 key의 인덱스
    if(k == 0):
        return
    else:
        p = Node(key[k])
        p.l_child = tree(key, r, i, k-1)
        p.r_child = tree(key, r, k+1, j)
        return p


def inOrder(root):  # 중위 순회로 트리 출력
    if not root:
        return
    inOrder(root.l_child)
    print(root.data)
    inOrder(root.r_child)


def preOrder(root):  # 전위 순회로 트리 출력
    if not root:
        return
    print(root.data)
    preOrder(root.l_child)
    preOrder(root.r_child)


def optSearchTree(n, p, a, r):  # n: 데이터 길이 p: 확률 리스트 a: 최소 검색시간 담은 리스트 r: 그때의 루트의 인덱스
    for i in range(1, n+1):
        a[i][i] = p[i]
        r[i][i] = i

    for diag in range(1, n):
        for i in range(1, n-diag+1):
            j = i + diag
            psum = sum(p[i:j+1])  # i부터 j까지의 p의 합
            for k in range(i, j+1):
                compareValue = a[i][k-1] + a[k+1][j]
                if(a[i][j] == 0):  # 0이면 최초로 연산에 들어온 것이므로 초기화
                    a[i][j] = compareValue
                    r[i][j] = k
                else:
                    if(a[i][j] > compareValue):
                        r[i][j] = k
                        a[i][j] = compareValue
            a[i][j] += psum  # 34줄이나 36줄에 넣으면 pm값이 중복으로 더해짐
#---------------------------------------------문제 1 모듈 ----------------------------------------------#

#---------------------------------------------문제 2 모듈 ----------------------------------------------#


def fillMatrix(x, y, table, minindex):  # table과 minindex를 구함, x = 긴 DNA, y = 짧은 DNA
    for i in range(len(x)-1, -1, -1):  # 마지막 열 맨 밑에서부터 맨 위까지, 왼쪽 대각선 밑으로 테이블을 채움
        j = len(y)-1
        while(i < len(x) and j >= 0):
            penalty = 0 if x[i] == y[j] else 1
            a = table[i+1][j+1] + penalty
            b = table[i+1][j]+2
            c = table[i][j+1]+2
            table[i][j] = min(a, b, c)
            if min(a, b, c) == a:
                minindex[i][j] = (i+1, j+1)  # 오른쪽 밑 대각선 방향 저장
            elif min(a, b, c) == b:
                minindex[i][j] = (i+1, j)  # 밑 칸 저장
            else:
                minindex[i][j] = (i, j+1)  # 오른쪽 칸 저장
            i += 1
            j -= 1

    for j in range(len(y)-2, -1, -1):  # 남은 테이블을 오른쪽에서부터 왼쪽 밑 대각선 방향으로 채움
        i = 0
        while(i <= len(y)-2 and j >= 0):
            penalty = 0 if x[i] == y[j] else 1
            a = table[i+1][j+1] + penalty
            b = table[i+1][j]+2
            c = table[i][j+1]+2
            table[i][j] = min(a, b, c)
            if min(a, b, c) == a:
                minindex[i][j] = (i+1, j+1)
            elif min(a, b, c) == b:
                minindex[i][j] = (i+1, j)
            else:
                minindex[i][j] = (i, j+1)
            i += 1
            j -= 1


def print_minindex(a, b, minindex):
    x = y = 0
    while (x < len(a) and y < len(b)):
        tx, ty = x, y
        print(minindex[x][y])
        (x, y) = minindex[x][y]
        if x == tx+1 and y == ty+1:  # 배열 [i][j]칸 도달하기 위해 대각선으로 이동하는 경우
            print(a[tx], " ", b[ty])
        elif x == tx and y == ty+1:  # 배열 [i][j]칸 도달하기 위해 왼쪽으로 이동하는 경우
            print(" - ", " ", b[ty])
        else:  # 배열 [i][j]칸 도달하기 위해 위로 이동하는 경우
            print(a[tx], " ", " -")


def printMatrix(d):
    m = len(d)
    n = len(d[0])

    for i in range(0, m):
        for j in range(0, n):
            print('{0:2}'.format(d[i][j]), end=" ")
        print()

#---------------------------------------------문제 2 모듈 ----------------------------------------------#


def main1():
    print('문제 1')
    data1 = ['', 'A', 'B', 'C', 'D', 'E']
    data2 = ['', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']

    p1 = [0, 1/15, 2/15, 3/15, 4/15, 5/15]
    p2 = [0, 1/8, 1/8, 1/8, 1/8, 1/8, 1/8, 1/8, 1/8]

    a1 = np.zeros((len(data1)+2, len(data1) + 2))
    a2 = np.zeros((len(data2)+2, len(data2) + 2))

    r1 = np.zeros((len(data1)+2, len(data1) + 2), dtype=int)
    r2 = np.zeros((len(data2)+2, len(data2) + 2), dtype=int)

    optSearchTree(len(data1)-1, p1, a1, r1)
    optSearchTree(len(data2)-1, p2, a2, r2)

    print('세 번째 소수점까지 반올림한 data1 최소 검색시간 츨력')
    print(np.round_(a1, 3))
    print()

    print('data1 최소 검색시간에 대한 루트 출력')
    print(r1)
    print()

    print()

    print('data2 최소 검색시간 출력')
    print(a2)
    print()

    print('data2 최소 검색시간에 대한 루트 출력')
    print(r2)
    print()

    a1tree = tree(data1, r1, 1, len(data1)-1)
    print('data1 전위순회 출력')
    preOrder(a1tree)
    print()
    print('data1 중위순회 출력')
    inOrder(a1tree)
    print()

    a2tree = tree(data2, r2, 1, len(data2)-1)
    print('data2 전위순회 출력')
    preOrder(a2tree)
    print()
    print('data2 중위순회 출력')
    inOrder(a2tree)

    print('#-------------------------------------------------------------------------#')


def main2():
    print('문제 2')
    a = ['G', 'A', 'C', 'T', 'T', 'A', 'C', 'C']
    b = ['C', 'A', 'C', 'G', 'T', 'C', 'C', 'A', 'C', 'C']

    if(len(a) < len(b)):  # 알고리즘에서 a가 더 긴 것으로 하여 만약 a가 더 짧으면 교환
        a, b = b, a

    m = len(a)
    n = len(b)
    table = [[0 for j in range(0, n+1)] for i in range(0, m+1)]
    minindex = [[(0, 0) for j in range(1, n+1)] for i in range(0, m+1)]

    for j in range(n-1, -1, -1):
        table[m][j] = table[m][j+1] + 2
    for i in range(m-1, -1, -1):
        table[i][n] = table[i+1][n] + 2

    fillMatrix(a, b, table, minindex)

    print('DNA 서열 맞춤 알고리즘 Output')
    printMatrix(table)
    print()

    print('서열 맞춤 결과')
    print_minindex(a, b, minindex)


main1()
main2()
