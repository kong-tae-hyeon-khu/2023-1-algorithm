
#------------------------------main 1------------------------------#

def main1():
    inf = 1000
    w = [[0, 15, 4, 11, 5], [inf, 0, inf, 1, inf],
         [inf, 4, 0, 2, inf], [inf, inf, inf, 0, inf], [inf, 3, inf, 1, 0]]

    n = 5
    f = set()  # e 저장
    touch = n*[0]  # 최단경로 <v, vi>에서 Y에 속한 정점 v
    length = n*[0]  # Y에 속한 정점들만 사용하여 v0에서 vi로 가는 현재 최단경로 길이
    save_length = n*[0]  # 최단경로 길이 저장
    vnear = -1  # 이번에 찾은 최소 정점
    NoC = 0  # length Update 횟수
    for i in range(1, n):
        length[i] = w[0][i]

    for i in w:
        for j in i:
            if(j != inf and j != 0):  # inf, 자기자신(0)이 아니면 간선이 있다는 것이므로 더함
                NoC += 1

    for i in range(1, n):
        min = inf
        for j in range(1, n):
            if(length[j] >= 0 and length[j] < min):
                min = length[j]
                vnear = j  # 이번에 찾은 최소거리 정점
        e = (touch[vnear], vnear)
        f.add(e)  # 최소 간선 저장
        save_length[vnear] = min  # 최소 거리 저장

        for i in range(1, n):  # 업데이트
            if(length[vnear] + w[vnear][i] < length[i]):
                length[i] = length[vnear] + w[vnear][i]
                touch[i] = vnear
        # if(length[j] >= 0 and length[j] < min) 조건에 안걸리도록(Y에 정점 추가)
        length[vnear] = -1

    NoC -= len(f)
    print('-------------------- 문제1 --------------------')
    print('간선들의 집합: ', f)
    print('최단경로의 값:', save_length)
    print('length의 업데이트 횟수:', NoC)
    print()

#--------------------------------main2-------------------------------#


count = 0  # 생성한 상태공간트리의 총 노드 수
result = 0  # 해의 총 개수


def promising(i, col):
    k = 0
    switch = True
    while(k < i and switch):
        if(col[i] == col[k] or abs(col[i] - col[k]) == i - k):  # 같은 열 || 대각선내에 위치하는지 검사
            switch = False
        k += 1
    global count
    count += 1
    return switch


def queens(n, i, col):
    if(promising(i, col)):  # 노드 하나 생성 & 그 노드가 적합한지 판정
        if(i == n-1):  # 결과 하나 생성
            global result
            result += 1
            print(col)
        else:  # 그 다음 행의 열들의 promising 검사
            for j in range(0, n):
                col[i+1] = j
                queens(n, i+1, col)


def main2():

    n = 7
    col = n*[0]
    print('-------------------- 문제2 --------------------')
    print('해집합')
    queens(n, -1, col)
    print('생성한 상태공간트리의 총 노드 수:', count)
    print('해의 총 개수:', result)


main1()
main2()
