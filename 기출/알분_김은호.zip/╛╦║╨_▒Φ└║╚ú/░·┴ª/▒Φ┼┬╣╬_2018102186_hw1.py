import time
from random import *


def make_random_list(size):
    arr = []
    for i in range(size):
        num = randint(1, 1000)
        arr.append(num)
    return arr


def make_random_list_nodup(size):  # 중복 없는 난수 리스트 생성
    arr = []
    num = randint(1, size)
    for i in range(size):
        while num in arr:
            num = randint(1, size)
        arr.append(num)
    return arr


def partition(s, low, high):
    pivotitem = s[low]  # s의 처음(low)아이템이 pivotItem
    j = low
    for i in range(low+1, high+1):
        if(s[i] < pivotitem):
            j = j + 1
            s[i], s[j] = s[j], s[i]  # pivotItem보다 작은 것이 있으면 교환
    pivotpoint = j  # pivotItem보다 작았던 것중에 가장 마지막 idx
    # pivotpoint 왼쪽으로는 작은 것, 오른쪽으론 큰 것
    s[low], s[pivotpoint] = s[pivotpoint], s[low]
    return pivotpoint


def quick_sort(s, low, high):
    if(high > low):
        pivotpoint = partition(s, low, high)
        quick_sort(s, low, pivotpoint-1)
        quick_sort(s, pivotpoint+1, high)


def insertion_sort(s):
    for i in range(1, len(s)):
        x = s[i]
        j = i-1
        while(j >= 0 and s[j] > x):
            s[j+1] = s[j]
            j = j - 1
        s[j+1] = x


arr_for_quick_5000 = make_random_list(5000)
arr_for_insertion_5000 = arr_for_quick_5000[:]

arr_for_quick_10000 = make_random_list(10000)
arr_for_insertion_10000 = arr_for_quick_10000[:]

s1 = time.time()
insertion_sort(arr_for_insertion_5000)
s2 = time.time()
print(f"Insertion Sort when n=5,000 {s2-s1: .5f} sec")


s1 = time.time()
quick_sort(arr_for_quick_5000, 0, len(arr_for_quick_5000) - 1)
s2 = time.time()
print(f"Quick Sort when n=5,000 {s2-s1: .5f} sec")
print('\n')

s1 = time.time()
insertion_sort(arr_for_insertion_10000)
s2 = time.time()
print(f"Insertion Sort when n=10,000 {s2-s1: .5f} sec")


s1 = time.time()
quick_sort(arr_for_quick_10000, 0, len(arr_for_quick_10000) - 1)
s2 = time.time()
print(f"Quick Sort when n=10,000 {s2-s1: .5f} sec")
print('\n')
