#----------------------------문제 1----------------------------#

def main1():
    count = 0

    def promising(i, weight, total):
        nonlocal count  # promising을 판단 -> 노드가 하나 생성
        count += 1
        # (weight + total < W) or (weight + w[i+1] > W and weight != W)의 not
        return (weight+total >= W) and (weight == W or weight+w[i+1] <= W)

    def s_s(i, weight, total, include):
        if(promising(i, weight, total)):
            if(weight == W):  # 해 발견
                print('해:', include)
            else:
                include[i+1] = 1  # yes
                s_s(i+1, weight+w[i+1], total-w[i+1], include)  # w[i+1] 포함
                include[i+1] = 0  # no
                s_s(i+1, weight, total-w[i+1], include)  # w[i+1] 포함 X

    W = 15
    w = [1, 2, 3, 4, 15]
    n = 5

    print('-------------------문제1-------------------')
    print('items =', w, 'W =', W)
    include = n*[0]
    total = 0
    for k in w:
        total += k
    s_s(-1, 0, total, include)
    print('총 노드 수:', count)

#----------------------------문제 2----------------------------#


def main2():
    count = 0
    result = 0

    def color(i, vcolor):
        if(promising(i, vcolor)):
            if(i == n-1):
                nonlocal result
                result += 1
                print(vcolor)
            else:
                for mcolor in range(1, m+1):
                    vcolor[i+1] = mcolor  # 다음 노드에 1~m까지 색을 다 넣어봄
                    color(i+1, vcolor)

    def promising(i, vcolor):
        nonlocal count
        count += 1  # promising 여부를 판단 -> 노드가 하나 생성
        switch = True
        j = 0
        while(j < i and switch):  # i-1번째 까지 검사
            if(W[i][j] and vcolor[i] == vcolor[j]):  # 연결되어 있는 것이 서로 같은 색깔인지 검사
                switch = False
            j += 1

        return switch

    n = 5
    W = [[0, 1, 1, 0, 1],
         [1, 0, 1, 1, 0],
         [1, 1, 0, 1, 0],
         [0, 1, 1, 0, 1],
         [1, 0, 0, 1, 0]]
    vcolor = n*[0]

    print('-------------------문제2-------------------')
    for m in range(2, 5):  # planar graph이므로 4개의 색깔이면 충분하여 4개까지만 검사
        print('사용하는 색의 수 =', m)
        print('모든 해')
        color(-1, vcolor)
        print('해의 개수:', result)
        print('생성된 노드 수:', count)
        count = 0
        result = 0
        print()


main1()
print()
main2()
