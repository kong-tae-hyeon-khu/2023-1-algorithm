from heapq import merge
from random import *

# 1
class Data:
    __arr = [0] # 배열
    __count = 0 # 비교횟수
    __size = 0 # 배열의 크기

    def __init__(self, size): # 생성자
        self.__size = size + 1
        for i in range(size):
            num = randint(1, size)
            self.__arr.append(num)
        self.__arr.sort() # 오름차순 정렬

    def binSearch(self, x): # 이분탐색 
        low = 1
        high = self.__size
        while(low <= high):
            mid = (low + high) // 2
            if(self.__arr[mid] == x):
                self.__count += 1
                return mid
            elif(self.__arr[mid] < x):
                self.__count += 1
                low = mid + 1
            else:
                self.__count += 1
                high = mid - 1
        return 0

    def getCount(self): # 비교횟수 반환
        return self.__count


sum128 = sum256 = sum512 = 0

n_128 = Data(128)
n_256 = Data(256)
n_512 = Data(512)

for i in range(1000):
    rand_128 = randint(1, 128)
    n_128.binSearch(rand_128)
    sum128 += n_128.getCount()
    n_128.makeCountZero()

for i in range(1000):
    rand_256 = randint(1, 256)
    n_256.binSearch(rand_256)
    sum256 += n_256.getCount()
    n_256.makeCountZero()

for i in range(1000):
    rand_512 = randint(1, 512)
    n_512.binSearch(rand_512)
    sum512 += n_512.getCount()
    n_512.makeCountZero()

""" 
이분 탐색의 Big-O noation은 log2(n)이다. 
즉 n이 2배씩 커질수록 수행 시간이 1초씩 늘어나게 된다.
관찰결과,
n=128일 때 평균 비교횟수: 6.993
n=256일 때 평균 비교횟수 : 7.967
n=512일 때 평균 비교횟수 : 8.817
으로 실제로도 n이 2배씩 커질 때 수행 시간이 약 1초 늘어난 것을 확인할 수 있었다.
"""

#-----------------------------------------------------------------------#
# 2
count = 0 # 추가 공간 
def mergeSort(n, s):
    global count
    h = n // 2  # 왼쪽배열 크기
    m = n - h  # 오른쪽 배열 크기
    u = [0] * h  # 왼쪽배열
    v = [0] * m  # 오른쪽배열

    if n > 1:
        u = s[:h]
        v = s[h:]
        print("필요한 추가공간(왼쪽) : " + str(n//2)) # 왼쪽 배열 할당 때 필요한 크기
        print("필요한 추가공간(오른쪽) : " + str(n//2)) # 오른쪽 배열 할당 때 필요한 크기
        count += n
        mergeSort(h, u)
        print("왼쪽 배열 메모리 해제 : " + str(n//2)) # 왼쪽 배열 할당 해제
        count -= n // 2
        mergeSort(m, v)
        merge(h, m, u, v, s)


def merge(h, m, u, v, s):
    i = 0
    j = 0
    k = 0
    while i < h and j < m:
        if u[i] < v[j]:
            s[k] = u[i]
            i += 1
        else:
            s[k] = v[j]
            j += 1
        k += 1
    if i >= h: # v가 더 클 경우
        s[k:] = v[j:]
    else: # u가 더 클 경우
        s[k:] = u[i:]

def main():
    sum128 = sum256 = sum512 = 0

    n_128 = Data(128)
    n_256 = Data(256)
    n_512 = Data(512)

    for i in range(1000):
        rand_128 = randint(1, 128)
        n_128.binSearch(rand_128)
        sum128 += n_128.getCount()
        n_128.makeCountZero()

    for i in range(1000):
        rand_256 = randint(1, 256)
        n_256.binSearch(rand_256)
        sum256 += n_256.getCount()
        n_256.makeCountZero()

    for i in range(1000):
        rand_512 = randint(1, 512)
        n_512.binSearch(rand_512)
        sum512 += n_512.getCount()
        n_512.makeCountZero()

    avg128 = sum128 / 1000
    avg256 = sum256 / 1000
    avg512 = sum512 / 1000

    print("문제1")
    print('n=128일 때 평균 비교횟수: ' + str(avg128))
    print("n=256일 때 평균 비교횟수 : " + str(avg256))
    print("n=512일 때 평균 비교횟수 : " + str(avg512))
    print()

    print("문제2")
    s = [8, 3, 15, 2, 9, 1, 5, 7, 4, 16, 10, 11, 12, 13, 6, 14]
    mergeSort(len(s), s)
    print("정렬 후 : " + str(s))
    print("필요한 추가 공간 수 : " + str(count))

main()

