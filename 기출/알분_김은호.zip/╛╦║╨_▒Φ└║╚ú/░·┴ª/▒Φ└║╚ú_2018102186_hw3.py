import numpy as np
import matplotlib.pyplot as plt  # 그래프 그리기
from random import *
import math

count = 0  # 비교횟수


def quickSort(s, low, high) -> None:
    if(high > low):
        pivotPoint = partition(s, low, high)
        quickSort(s, low, pivotPoint-1)
        quickSort(s, pivotPoint+1, high)


def partition(s, low, high) -> int:
    j = low
    pivotItem = s[low]
    for i in range(low+1, high+1):
        global count
        count += 1
        if(s[i] < pivotItem):
            j += 1
            s[i], s[j] = s[j], s[i]
    s[low], s[j] = s[j], s[low]

    return j  # pivotpoint 반환


def make_random_list(n):  # 난수리스트 생성
    arr = []
    for i in range(n):
        num = randint(0, n)
        arr.append(num)
    return arr


def countZero():  # 비교횟수 초기화
    global count
    count = 0


def prod2(a, b):  # 큰 정수곱셈 2로 구현
    n = max(len(str(a)), len(str(b)))
    if(a == 0 or b == 0):
        return 0
    elif(n <= 2):
        return a * b
    else:
        m = math.floor(n/2)  # 바닥함수
        x = a // 10**m
        y = a % 10**m
        w = b // 10**m
        z = b % 10**m
        r = prod2(x+y, w+z)
        p = prod2(x, w)
        q = prod2(y, z)
        return p * 10**(2*m) + (r-p-q)*10**m + q


def main():
    #------------------------------- 문제 1 -----------------------------#

    n100 = n200 = n300 = n400 = 0

    for i in range(100):
        quickSort(make_random_list(100), 0, 99)
        n100 += count
        countZero()
        quickSort(make_random_list(200), 0, 199)
        n200 += count
        countZero()
        quickSort(make_random_list(300), 0, 299)
        n300 += count
        countZero()
        quickSort(make_random_list(400), 0, 399)
        n400 += count
        countZero()

    print("n = 100일 때 평균비교 횟수 : " + str(n100/100))
    print("n = 200일 때 평균비교 횟수 : " + str(n200/100))
    print("n = 300일 때 평균비교 횟수 : " + str(n300/100))
    print("n = 400일 때 평균비교 횟수 : " + str(n400/100))

    print()

    #------------------------------- 문제 2 -----------------------------#
    a = 1234567812345678
    b = 2345678923456789
    print("큰 정수 곱셈 알고리즘으로 계산 : " + str(prod2(a, b)))
    print("그냥 곱셈으로 계산 : " + str(a*b))

    # 그래프 그리기
    x = np.arange(100, 400)
    plt.plot([100, 200, 300, 400], [n100/100, n200 /
             100, n300/100, n400/100], label='Result')
    plt.legend()
    plt.xlabel('Data Size')
    plt.ylabel('Average')
    plt.xticks([100, 200, 300, 400])  # 간격 설정
    plt.show()


main()
