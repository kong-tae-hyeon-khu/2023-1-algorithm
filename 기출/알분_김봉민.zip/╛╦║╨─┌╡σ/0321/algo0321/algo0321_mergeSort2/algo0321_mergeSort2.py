def mergeSort2(s, low, high):
    if(low<high):
        mid = int((low + high) / 2)
        mergeSort2(s,low,mid)
        mergeSort2(s,mid+1,high)
        merge2(s,low,mid,high)
        
def merge2(s,low,mid,high):
    i = low
    j = mid + 1
    k = 0
    U = [0]*(high - low + 1)
    while(i<=mid and j<=high):
        if( s[i] < s[j]):
            U[k] = s[i]
            i+=1
        else:
            U[k] = s[j]
            j+=1
        k+=1
    if(i>mid):
        for ii in range(j,high+1):
            U[ii - j + k] = s[ii]
    else:
        for ii in range(i,mid+1):
            U[ii - i + k] = s[ii]
    for ii in range(low, high+1):
        s[ii] = U[ii - low]

 
s = [3,5,2,9,10,14,4,8]
mergeSort2(s,0,len(s)-1)
print(s)