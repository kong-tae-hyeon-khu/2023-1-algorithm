class binary_search:
    def __init__(self, data, item, low, high):
        self.data = data
        self.low = low
        self.high = len(data)
        self.item = item

    def bs(self):
        if (self.low > self.high):
            return -1
        else:
            mid = (self.low + self.high) // 2
        if (self.item == self.data[mid]):
            return mid
        elif (self.item > self.data[mid]):
            return self.bs()
        else:
            return self.bs()
  
data = [1,3,7]
n = 3
a = binary_search(data,3,0,n-1)

print(a.bs())

# RecursionError: maximum recursion depth exceeded in comparison
# RunTimeError 로 인해 작동이 잘 안 됨을 알 수 있다.