import utility

#prim

inf = 1000
w = [[0,1,3,inf,inf],
     [1,0,3,6,inf],
     [3,3,0,4,2],
     [inf,6,4,0,5],
     [inf,inf,2,5,0]] #한번에 가는 노드 to 노드 길이

F=set()
utility.printMatrix(w)
n=len(w)
nearest=n*[0]
distance=n*[0]
for i in range(1,n):
    nearest[i]=0
    distance[i] = w[0][i]
print("nearest:",nearest)
print("distance:",distance)
print()
for k in range(1,n):
    minVal = inf 
    for i in range(1,n):
        if(distance[i]>=0 and distance[i]<minVal):
            minVal = distance[i]
            vnear = i
    F.add((vnear, nearest[vnear])) #노드 연결
    print(F)
    distance[vnear] = -1
    print("nearest:",nearest)
    print("distance:",distance)
    for i in range(1,n):            # Y에 없는 각 노드에 대해서 distance[i]를 갱신한다.
        if(w[i][vnear] < distance[i]): 
            distance[i] = w[i][vnear]
            nearest[i] = vnear
    print("Update_nearest:",nearest)
    print("Update_distance:",distance)
    print()

print()
print(F) # +1씩 해서 생각해야됨.

#---------------------------------------------↓kruskals graph
print()
print("kruskal")
parent = dict()
rank = dict()

def make_singleton_set(v):
    parent[v] = v
    rank[v] = 1
    
def find(v):
    if parent[v] != v:
        parent[v] = find(parent[v])
    return parent[v]

def union(r1,r2):

    if r1 != r2:
        if rank[r1] > rank[r2]:
            parent[r2] = r1
            rank[r1] += rank[r2]
        else:
            parent[r1] = r2
            if rank[r1] == rank[r2]: rank[r2]+=rank[r1]  

def kruskal(graph):
    for v in graph['vertices']:
        make_singleton_set(v)
    mst = set()
    edges = list(graph['edges'])
    edges.sort()
    print(edges)
    for edge in edges:
        weight, v1, v2 = edge
        r1 = find(v1)
        r2 = find(v2)
        if r1 != r2:
            union(r1,r2)
            mst.add(edge)
    return mst

graph = {
         'vertices': ['A','B','C','D','E'],
         'edges': set([
             (1,'A','B'),
             (3,'A','C'),
             (3,'B','C'),
             (6,'B','D'),
             (4,'C','D'),
             (2,'C','E'),
             (5,'D','E'),
          ])
}

mst = kruskal(graph)
print(mst)