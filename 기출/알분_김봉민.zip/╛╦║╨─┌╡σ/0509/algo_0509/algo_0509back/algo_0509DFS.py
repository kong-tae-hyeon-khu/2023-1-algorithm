import utility

e={0:[1,2,3], 1:[2,5], 2:[3,4,5,6], 3:[4,6], 4:[6,7]}
n=8
a = [[0 for j in range(0,n)] for i in range(0,n) ]

for i in range(0,n-1):
    for j in range(i+1,n):
        if i in e:
            if j in e[i]:
                a[i][j]=1
                a[j][i]=1
utility.printMatrix(a)            # 이 행렬은 e를 의미. 각 노드가 어떤 노드와 연결 되어있는지

visited = n*[0]

def DFS(a,v):
    visited[v]=1
    print(v)
    for x in range(0,n):
        if a[v][x] == 1 and visited[x] ==0:
            DFS(a,x)
DFS(a,0)